package com.igate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.igate.dao.ProductDaoImpl;
import com.igate.dto.Product;

@Service("serviceImpl")
public class ProductServiceImp implements ProductService {
	
	@Autowired
	@Qualifier("daoImpl")
	public ProductDaoImpl prodDao;

	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		
		return prodDao.getAllProd();
	}

	public List<Product> getSingleRecord(String id) {
		// TODO Auto-generated method stub
		System.out.println(id+"from service impl");
		return prodDao.getRecord(id);
	}

}
