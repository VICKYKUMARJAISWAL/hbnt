package com.igate.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.dto.Employee;
import com.igate.service.EmployeeServiceImpl;



@Controller
public class EmployeeController {

 @Autowired
 @Qualifier("empService")
 private EmployeeServiceImpl employeeService;
 
 @RequestMapping(value="/displayAllRecord",method=RequestMethod.GET)
 public String getAllEmployeeRecord(Model model){
	 
	    List<Employee> allEmployeeData=employeeService.getAllEmployee();
	    
	    model.addAttribute("empList", allEmployeeData);
	    
	    return "ShowAllEmployeeRecord";
	    
	 
	 
	 
 }
 
	
 	

	


}
