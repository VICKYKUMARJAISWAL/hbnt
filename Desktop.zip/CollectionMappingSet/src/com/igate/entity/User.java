package com.igate.entity;

import java.util.HashSet;
import java.util.Set;

public class User {
	private Long id;
	private String userName;
	Set<String> sports = new HashSet<String>();
	Set<Address> address = new HashSet<Address>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Set<String> getSports() {
		return sports;
	}

	public void setSports(Set<String> sports) {
		this.sports = sports;
	}

	public Set<Address> getAddress() {
		return address;
	}

	public void setAddress(Set<Address> address) {
		this.address = address;
	}

	
	
}
