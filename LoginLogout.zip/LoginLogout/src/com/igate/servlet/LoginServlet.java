package com.igate.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet{

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		req.getRequestDispatcher("link.html").include(req, res);
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		
		if(name.equalsIgnoreCase(password))
		{
			pw.println("Login successfull");
			pw.println("Mr. "+" "+name);
			Cookie cookies = new Cookie("name",name);
			//Cookie cookies1 = new Cookie("password",password);
			res.addCookie(cookies);
			//res.addCookie(cookies1);
			
		}
		else
		{
			pw.println("Login is denied");
			req.getRequestDispatcher("link.html").include(req, res);
		}
		
	}
	

}
