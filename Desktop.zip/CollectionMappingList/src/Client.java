import java.util.ArrayList;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.igate.entity.Address;
import com.igate.entity.User;
import com.igate.util.HibernateUtil;


public class Client {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			ArrayList<String> sports = new ArrayList<String>();
			sports.add("Tennis");
			sports.add("VolleyBall");
			
			ArrayList<Address> addList= new ArrayList<Address>();
			addList.add(new Address("Pune", "Maharashtra", "India"));
			addList.add(new Address("Chennai", "Tamil Nadu", "India"));
			
			User user = new User();
			user.setUserName("Edward");
			user.setSports(sports);
			user.setAddress(addList);
			session.save(user);
			transaction.commit();
			System.out.println(" ========Users Created==========");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
