package com.igate.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.model.CommandClass;

@Controller
public class ControllerClass 
{
	//public static Logger logger = Logger.getLogger(ControllerClass.class);
	
	@RequestMapping(value="/login.html",method=RequestMethod.GET)
	public String viewLogin(Map<String,Object> model)
	{
		
		CommandClass user = new CommandClass();
		model.put("userForm", user);
		return "Login";
	}
	
	@RequestMapping(value="/check.html",method=RequestMethod.POST)
	public String doLogin(@Valid @ModelAttribute("userForm") CommandClass userForm,BindingResult result,Map<String,Object> model)
	{
		
		if(result.hasErrors())
		{
			return "Login";
		}
		return "LogginSuccess";
	}
	
}

