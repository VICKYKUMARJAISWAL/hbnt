package com.igate.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.igate.dto.Employee;

@Repository("empDAO")
public class EmployeeDaoIml implements IEmployeeDao {

	
	@Autowired
	private JdbcTemplate jt;

	public List<Employee> getAllEmployee() {
	       
		String selectSql="select *from Employee";
		
		
		
		return jt.query(selectSql, new RowMapper<Employee>(){
			
			public Employee mapRow(ResultSet rs,int row)throws SQLException
			{
				 Employee employee=new Employee();
				 employee.setId(rs.getInt(1));
				 employee.setName(rs.getString(2));
				 employee.setSalary(rs.getFloat(3));
				 
				 return employee;
				
			}
			
		});
	
	
	}
	
	





}
