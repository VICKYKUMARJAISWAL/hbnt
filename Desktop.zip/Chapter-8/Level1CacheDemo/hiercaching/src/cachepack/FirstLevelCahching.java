package cachepack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.igate.entity.*;

//1)In order to visualize the first level of cache we have to see the console and
//analyse the no of Queries fired by the hibernate . 
//2)save only que's the objects to be persisted.flush synchronises 
//them ...session.close does the commit
public class FirstLevelCahching {
	public static void main(String[] args)throws Exception {
		Student student = null;
		Student student1=null;
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		org.hibernate.Transaction tran=session.beginTransaction();
		
		tran.begin();
		student = new Student();
		student.setStudentName("Roshan");		
		student.setStudentId(88);
		student.setStudentMarks(99.9);
						
		student1=new Student();
		student1.setStudentId(33);
		student1.setStudentName("Rajeev");
		student1.setStudentMarks(87.0);
		
		//some data is requred in tables for testing Cahche.Once data get inserted 
		//we can comment the below lines.
		
	session.save(student);
	session.save(student1);
	session.flush();
	tran.commit();
	session.close();
		
//Testing First level cache when same record is fetched two times within one session
//In the below code although two times get() is called only one time hibernate will fire select query	
	
		
	Session session1 = sf.openSession();
						
	System.out.println(" ========= Select Query Fired Only Once (Uses Level 1 cache of Same Session)==========");
	Student st = (Student) session1.get(Student.class, new Integer(33));
	System.out.println("First Fetch : student Name="+st.getStudentName());
												
	Student  st1= (Student) session1.get(Student.class, new Integer(33));
						System.out.println("Second Fetch: Student Name="+st.getStudentName());
									      
	session1.close();
	
	//Student Object created in different sessions and testing when extracting same data from two different session
	//In this case two times select Query will be fired by hibernate
	System.out.println(" ========= Two times Select Query Fired (Different Session) ===========");
	Session session2 = sf.openSession();
	Student st2 = (Student) session2.get(Student.class, new Integer(33));
	System.out.println(" First Fetch : Name="+st2.getStudentName());
	session2.close();
	
	Session session3 = sf.openSession();
	Student st3 = (Student) session3.get(Student.class, new Integer(33));
	System.out.println("Second Fetch :  Name="+st3.getStudentName());
	session3.close();
								
									
									
	System.out.println(" done");				
									
	}
}
