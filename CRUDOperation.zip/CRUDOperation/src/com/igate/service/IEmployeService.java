package com.igate.service;

import java.util.List;

import com.igate.dto.Employee;

public interface IEmployeService {


	  public List<Employee> getAllEmployee(); 




}
