package com.igate.dto;

public class Product {
	public String pId;
	public String name;
	public float price;
	
	public Product(String pId,String name,float price) {
		// TODO Auto-generated constructor stub
		super();
		this.pId=pId;
		this.name=name;
		this.price=price;
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public String getpId() {
		return pId;
	}

	public void setpId(String pId) {
		this.pId = pId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	

}
