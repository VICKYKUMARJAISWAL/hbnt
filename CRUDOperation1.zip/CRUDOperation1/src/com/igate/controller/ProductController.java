package com.igate.controller;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.swing.text.html.HTMLDocument.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.dto.Product;
import com.igate.service.ProductServiceImp;

@Controller
public class ProductController {

	@Autowired
	@Qualifier("serviceImpl")
	public ProductServiceImp serviceImpl;
	PrintWriter out;
	@RequestMapping(value = "/showAllProd", method = RequestMethod.GET)
	public String showAllProduct(Model model) {
		
		List<Product> allProd = serviceImpl.getAllProduct();
		model.addAttribute("prodList", allProd);
		return "showAllProduct";
	}
	
	@RequestMapping(value="/showById",method=RequestMethod.POST)
	public String showById(Model model,ServletRequest req)
	{
		System.out.println("hi hello");
		String id=req.getParameter("id");
		//HttpSession session = req.setAttribute("id", arg1);
		if(id==null){
			 out.println("Dont pass id as null");
				
			 return "error";
		}
		else
		{
			List<Product> getRecord = serviceImpl.getSingleRecord(id);
			//System.out.println(getRecord);
							
			model.addAttribute("record",getRecord);
			return "showById";
			
			 //System.out.println("initiated");
			 //System.out.println("initiated");
		//System.out.println(id+"vicky");
		
		}
		
		
		
	}

}
