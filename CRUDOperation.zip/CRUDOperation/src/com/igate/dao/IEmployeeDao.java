package com.igate.dao;

import java.util.List;

import com.igate.dto.Employee;

public interface IEmployeeDao {

	public List<Employee> getAllEmployee(); 
	
	
}
