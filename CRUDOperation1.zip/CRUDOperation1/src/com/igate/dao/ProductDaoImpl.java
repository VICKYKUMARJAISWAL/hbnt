package com.igate.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.igate.dto.Product;
@Repository("daoImpl")
public class ProductDaoImpl implements ProductDao{
	
	@Autowired
	JdbcTemplate jt;
	String sql;
	PrintWriter out;
	HttpServletResponse req;
	public List<Product> getAllProd() 
	{
		// TODO Auto-generated method stub
		 sql="select * from product";
		return jt.query(sql, new RowMapper<Product>(){

			public Product mapRow(ResultSet rs, int row) throws SQLException {
				// TODO Auto-generated method stub
				Product prod = new Product();
				prod.setpId(rs.getString(1));
				prod.setName(rs.getString(2));
				prod.setPrice(rs.getFloat(3));
				return prod;
			}
			
		});
				
	}

	public List<Product> getRecord(String id) {
		// TODO Auto-generated method stub
		if(id!=null){
		 sql="select * from product where id="+id;
		}
		else
		{
			try
			{
			 out =  req.getWriter();
			 out.println("dont pass id as null");
			}catch(IOException o)
			{
				o.printStackTrace();
			}
		}
		//System.out.println("hi from productDao");
		//int count = Integer.parseInt(sql);
		//System.out.println("count"+count);
		return jt.query(sql, new RowMapper<Product>(){

			public Product mapRow(ResultSet rs, int row) throws SQLException {
				// TODO Auto-generated method stub
				Product pro = new Product();
				pro.setpId(rs.getString(1));
				pro.setName(rs.getString(2));
				pro.setPrice(rs.getFloat(3));
				return pro;
			}
			
		
		});
		
	}

}
