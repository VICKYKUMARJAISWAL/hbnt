package com.igate.service;

import java.util.List;

import com.igate.dto.Product;

public interface ProductService {
	public List<Product> getAllProduct();

}
