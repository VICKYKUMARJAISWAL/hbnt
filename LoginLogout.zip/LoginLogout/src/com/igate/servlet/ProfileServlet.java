package com.igate.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProfileServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		Cookie[] value = req.getCookies();
		if(value!=null)
		{
			String name= value[0].getValue();
			//System.out.println(name);
			//String password = value[1].getValue();
			if(name!=null ||!name.equals(" "))
			{
				req.getRequestDispatcher("link.html").include(req, res);
				out.println("Welcome "+" "+name);
			}
			else
			{
				req.getRequestDispatcher("link.html").include(req, res);

				out.println("please first login to view your profle");
			}
		}
		else
		{
			out.println("please first login to view your profile");
		}
		
		
	}
	

}
