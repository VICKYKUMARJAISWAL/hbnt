package com.igate.dao;

import java.util.List;

import com.igate.dto.Product;

public interface ProductDao {
	public List<Product> getAllProd();
	public List<Product> getRecord(String id);

}
