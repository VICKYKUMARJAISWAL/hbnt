import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.igate.entity.Address;
import com.igate.entity.User;
import com.igate.util.HibernateUtil;

public class Client {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Map<String, String> sports = new HashMap<String, String>();
			sports.put("Sports1", "Hockey");
			sports.put("Sports2", "Tennis");

			HashMap<String, Address> addMap = new HashMap<String, Address>();
			addMap.put("add1", new Address("Pune", "MH", "India"));
			addMap.put("add2", new Address("Chennai", "TN", "India"));

			User user = new User();
			user.setUserName("Edward");
			user.setSports(sports);
			user.setAddress(addMap);

			session.save(user);
			transaction.commit();
			System.out.println(" ========Users Created==========");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
