package com.igate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.igate.dao.EmployeeDaoIml;
import com.igate.dto.Employee;

@Service("empService")
public class EmployeeServiceImpl implements IEmployeService {

	
	
	@Autowired
	@Qualifier("empDAO")
	private EmployeeDaoIml employeeDao; 
	
	public List<Employee> getAllEmployee() {
		
		
		  return employeeDao.getAllEmployee();
	
	}




}
