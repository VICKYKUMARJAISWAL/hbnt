package com.igate.entity;
public class ParttimeStudent extends Student
{
	private int hours;
	public int getHours()
	{
		return hours;
	}
	public void setHours(int hours) 
	{
		this.hours = hours;     
	}
} 
