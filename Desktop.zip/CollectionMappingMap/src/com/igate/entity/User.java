package com.igate.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class User {
	private Long id;
	private String userName;
	Map<String, String> sports = new HashMap();	
	Map<String, Address> address = new HashMap<String, Address>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Map<String, String> getSports() {
		return sports;
	}

	public void setSports(Map<String, String> sports) {
		this.sports = sports;
	}

	public Map<String, Address> getAddress() {
		return address;
	}

	public void setAddress(Map<String, Address> address) {
		this.address = address;
	}
	
	
}
